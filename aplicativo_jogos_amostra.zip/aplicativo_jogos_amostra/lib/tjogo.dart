class Tjogos{
  final String nome;
  final String dire_produ;
}