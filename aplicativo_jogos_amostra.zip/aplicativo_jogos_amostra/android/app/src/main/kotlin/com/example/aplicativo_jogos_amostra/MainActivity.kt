package com.example.aplicativo_jogos_amostra

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
